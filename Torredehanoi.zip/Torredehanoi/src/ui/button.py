import pygame
from src.config.settings import BUTTON_COLOR, BUTTON_HOVER, TEXT_COLOR


# ============================================================
# FUNCIONES AUXILIARES
# ============================================================
def draw_gradient_rect(surface, rect, color1, color2, border_radius):
    """Dibuja un rectángulo con un gradiente vertical sutil."""
    temp_surf = pygame.Surface(rect.size, pygame.SRCALPHA)
    
    # Crear un gradiente de color1 a color2 (ej: para darle brillo superior)
    for y in range(rect.height):
        ratio = y / rect.height
        r = color1[0] * (1 - ratio) + color2[0] * ratio
        g = color1[1] * (1 - ratio) + color2[1] * ratio
        b = color1[2] * (1 - ratio) + color2[2] * ratio
        
        # Dibujar una línea (fila de píxeles) con el color interpolado
        pygame.draw.line(temp_surf, (int(r), int(g), int(b), 120), (0, y), (rect.width, y))
        
    # Aplicar el gradiente al cuerpo (clip al radio de borde)
    mask = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255), mask.get_rect(), border_radius=border_radius)
    temp_surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN) # Asegura la transparencia
    
    surface.blit(temp_surf, rect.topleft)


# ============================================================
# BOTÓN RECTANGULAR (con Glassmorphism mejorado)
# ============================================================
class Button:
    def __init__(self, rect, text, font, callback):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.font = font
        self.callback = callback

        # Animación de hover
        self.hover_scale = 0
        self.max_scale = 6
        self.time = 0 # Para animaciones internas

    def draw(self, surface, dt=0):
        self.time += dt
        
        mouse_pos = pygame.mouse.get_pos()
        is_hover = self.rect.collidepoint(mouse_pos)

        # Animación de escala (suave)
        if is_hover:
            self.hover_scale = min(self.hover_scale + 1, self.max_scale)
        else:
            self.hover_scale = max(self.hover_scale - 1, 0)

        scaled_rect = self.rect.inflate(self.hover_scale, self.hover_scale)

        # 1. Sombra
        shadow = scaled_rect.copy()
        shadow.y += 6 # Sombra más marcada
        shadow_color = (0, 0, 0, 120)
        
        # Pygame necesita un Surface con SRCALPHA para el blending correcto.
        shadow_surf = pygame.Surface(shadow.size, pygame.SRCALPHA)
        pygame.draw.rect(shadow_surf, shadow_color, shadow_surf.get_rect(), border_radius=14)
        surface.blit(shadow_surf, scaled_rect.topleft)

        # 2. Cuerpo del botón (Glass con gradiente sutil)
        # Colores para el gradiente (oscuro abajo, claro arriba)
        color_top = (30, 45, 70) 
        color_bottom = (5, 15, 30)
        
        # Dibujar un rectángulo semi-transparente como base
        base_color = (30, 45, 70, 150)
        pygame.draw.rect(surface, base_color, scaled_rect, border_radius=14)

        # Dibujar el gradiente para el efecto de brillo/cristal
        draw_gradient_rect(surface, scaled_rect, color_top, color_bottom, 14)

        # 3. Borde (Neon)
        border_color = (0, 220, 255) if is_hover else (0, 150, 200)
        pygame.draw.rect(surface, border_color, scaled_rect, 2, border_radius=14)

        # 4. Glow suave (Neon)
        if is_hover:
            # Pulso sutil en el glow cuando está en hover
            pulse = (math.sin(self.time * 10) * 0.5 + 0.5) * 50 + 40 # Oscila entre 40 y 90
            glow_color = (0, 220, 255, int(pulse))

            glow = pygame.Surface((scaled_rect.width + 16, scaled_rect.height + 16), pygame.SRCALPHA)
            pygame.draw.rect(glow, glow_color,
                             (0, 0, glow.get_width(), glow.get_height()),
                             border_radius=18)
            surface.blit(glow, (scaled_rect.x - 8, scaled_rect.y - 8))

        # 5. Texto
        text_color = (255, 255, 255) if is_hover else (200, 240, 255)
        text_surf = self.font.render(self.text, True, text_color)
        surface.blit(text_surf, text_surf.get_rect(center=scaled_rect.center))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.callback:
                    self.callback()


# ============================================================
# BOTÓN CIRCULAR PARA PAUSA (Estilo Neon PULSANTE)
# ============================================================
import math # Necesario para el efecto de pulso

class NeonPauseButton:
    def __init__(self, x, y, radius=25, label=None, callback=None):
        self.x = x
        self.y = y
        self.radius = radius
        self.callback = callback
        self.label = label
        self.time = 0 # Para animaciones internas

        # Colores
        self.base_color = (0, 220, 255)
        self.glow_color_base = (0, 180, 255)
        self.rect = pygame.Rect(x - radius, y - radius, radius * 2, radius * 2) # Para colisión

        # Fuente para texto dentro del botón
        self.font = pygame.font.SysFont("bahnschrift", radius)
        
    def update(self, dt):
        self.time += dt
        
    def is_hover(self, pos):
        mx, my = pos
        return (mx - self.x)**2 + (my - self.y)**2 <= self.radius**2

    def draw(self, surface):
        mouse_pos = pygame.mouse.get_pos()
        is_hover = self.is_hover(mouse_pos)

        # Pulso de la luz neón
        pulse = (math.sin(self.time * 5) * 0.5 + 0.5) # Oscila entre 0 y 1
        
        # Ajustar la intensidad del glow (más intenso al hacer hover)
        glow_alpha = int(self.time * 200) % 150 + 50 # Un parpadeo constante
        if is_hover:
            glow_alpha = 180 + int(pulse * 75) # Más fuerte y dinámico

        # 1. Glow externo (pulso)
        glow = pygame.Surface((self.radius * 4, self.radius * 4), pygame.SRCALPHA)
        glow_color = self.glow_color_base + (glow_alpha,) # Agregar el alpha variable
        pygame.draw.circle(glow, glow_color,
                           (self.radius * 2, self.radius * 2),
                           self.radius * 2)
        surface.blit(glow, (self.x - self.radius * 2, self.y - self.radius * 2))

        # 2. Círculo principal (solo borde)
        pygame.draw.circle(surface, self.base_color, (self.x, self.y), self.radius, width=3)

        # 3. Contenido del botón (Icono Pausa o Label)
        if self.label:
            # Si tiene label → texto
            text_surf = self.font.render(self.label, True, (255, 255, 255))
            rect = text_surf.get_rect(center=(self.x, self.y))
            surface.blit(text_surf, rect)

        else:
            # Icono pausa (dos barras verticales)
            bar_w = 6
            bar_h = self.radius + 5

            pygame.draw.rect(surface, self.base_color,
                             (self.x - 10, self.y - bar_h // 2, bar_w, bar_h),
                             border_radius=3)

            pygame.draw.rect(surface, self.base_color,
                             (self.x + 4, self.y - bar_h // 2, bar_w, bar_h),
                             border_radius=3)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.is_hover(event.pos):
                if self.callback:
                    self.callback()


# ============================================================
# BOTÓN REDONDO CON TEXTO (Estilo Neon PULSANTE)
# ============================================================
class NeonRoundButton:
    def __init__(self, x, y, radius=25, text="", callback=None):
        self.x = x
        self.y = y
        self.radius = radius
        self.text = text
        self.callback = callback
        self.time = 0 # Para animaciones internas

        self.base_color = (0, 220, 255)
        self.glow_color_base = (0, 180, 255)
        self.rect = pygame.Rect(x - radius, y - radius, radius * 2, radius * 2) # Para colisión

    def update(self, dt):
        self.time += dt
        
    def is_hover(self, pos):
        mx, my = pos
        return (mx - self.x)**2 + (my - self.y)**2 <= self.radius**2

    def draw(self, surface):
        mouse_pos = pygame.mouse.get_pos()
        is_hover = self.is_hover(mouse_pos)
        
        # Pulso de la luz neón
        pulse = (math.sin(self.time * 5) * 0.5 + 0.5)
        
        # Ajustar la intensidad del glow (más intenso al hacer hover)
        glow_alpha = int(self.time * 200) % 150 + 50
        if is_hover:
            glow_alpha = 180 + int(pulse * 75)

        # 1. Glow externo
        glow = pygame.Surface((self.radius * 4, self.radius * 4), pygame.SRCALPHA)
        glow_color = self.glow_color_base + (glow_alpha,) # Agregar el alpha variable
        pygame.draw.circle(glow, glow_color,
                           (self.radius * 2, self.radius * 2),
                           self.radius * 2)
        surface.blit(glow, (self.x - self.radius * 2, self.y - self.radius * 2))

        # 2. Círculo principal
        pygame.draw.circle(surface, self.base_color, (self.x, self.y), self.radius, width=3)

        # 3. Texto interno
        font = pygame.font.SysFont("bahnschrift", 24)
        text_surf = font.render(self.text, True, (255, 255, 255))
        rect = text_surf.get_rect(center=(self.x, self.y))
        surface.blit(text_surf, rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.is_hover(event.pos):
                if self.callback:
                    self.callback()
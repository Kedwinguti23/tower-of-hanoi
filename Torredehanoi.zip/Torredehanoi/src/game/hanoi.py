import pygame
from src.config.settings import *
import math

# Altura máxima del arco de la parábola para la animación
ARC_HEIGHT = 150 

class HanoiGame:
    # -----------------------------------------------------------
    # INIT
    # -----------------------------------------------------------
    def __init__(self, level, game=None, time_enabled=True):
        self.game = game
        self.level = level
        self.time_enabled = time_enabled

        self.num_disks = 2 + level
        self.pegs = [list(range(1, self.num_disks + 1)), [], []]

        self.moves = 0
        self.min_moves = (2 ** self.num_disks) - 1

        # Tiempo
        if self.time_enabled:
            # FIX: El cálculo del tiempo ahora es parte de la clase para la barra.
            self.time_limit = 30 + int(self.min_moves * 1.5)
            self.time_left = self.time_limit
        else:
            self.time_limit = None
            self.time_left = None

        self.score = 0
        self.finished = False
        self.won = False

        self.dragging_disk = None
        self.drag_from_peg = None

        # Visual
        self.highlight_alpha = 0
        self.shadow_offset = 10
        self.shake_timer = 0
        self.shake_intensity = 0
        self.shake_direction = 1
        self.invalid_target = None

        self.animation = None

        self.peg_positions = self.calculate_peg_positions()

        # Tutorial
        self.tutorial_mode = False
        self.tutorial_moves = []
        self.tutorial_timer = 0

    # -----------------------------------------------------------
    def calculate_peg_positions(self):
        positions = []
        spacing = WIDTH / 3
        base_y = HEIGHT * 0.85

        for i in range(3):
            x = spacing * (i + 0.5)
            positions.append((int(x), int(base_y)))

        return positions

    # -----------------------------------------------------------
    def reset(self):
        self.pegs = [list(range(1, self.num_disks + 1)), [], []]

        if self.time_enabled:
            self.time_left = self.time_limit
        else:
            self.time_left = None

        self.moves = 0
        self.finished = False
        self.won = False
        self.score = 0
        self.dragging_disk = None
        self.drag_from_peg = None
        self.animation = None

        # Reset visual
        self.shake_timer = 0
        self.shake_intensity = 0
        self.invalid_target = None

        # Reset tutorial
        self.tutorial_mode = False
        self.tutorial_moves = []
        self.tutorial_timer = 0

    # -----------------------------------------------------------
    # ANIMACIÓN
    # -----------------------------------------------------------
    def start_drop_animation(self, disk, from_peg, to_peg):
        # La posición de inicio se calcula desde la parte superior del poste de origen
        # o se sobrescribe con la posición del mouse si fue arrastrado.
        
        disk_h = 22
        start_peg_y = self.peg_positions[from_peg][1]
        start_stack_height = len(self.pegs[from_peg]) # Ya hicimos pop(0) en el disco
        # Altura de inicio simulada: justo encima de donde estaba antes.
        start_y = start_peg_y - disk_h * (start_stack_height + 1) - (disk_h // 2)
        start_x = self.peg_positions[from_peg][0]

        # Calcular posición final (donde aterrizará)
        px, base_y = self.peg_positions[to_peg]
        final_y = base_y - disk_h * (len(self.pegs[to_peg]) + 1) - (disk_h // 2)

        if self.animation is None:
              # Si no hay animación previa (ej. modo tutorial), usamos la posición simulada
            start_pos = (start_x, start_y)
        else:
            # Si hay animación previa (ej. arrastre de usuario), usamos la posición del mouse
            start_pos = self.animation["start_pos"]


        self.animation = {
            "disk": disk,
            "from_peg": from_peg,
            "to_peg": to_peg,
            "progress": 0.0,
            "duration": 0.35, # Duración de la animación
            "start_pos": start_pos,
            "end_pos": (px, final_y)
        }

    def update_animation(self, dt):
        anim = self.animation
        anim["progress"] += dt / anim["duration"]

        if anim["progress"] >= 1:
            disk = anim["disk"]
            to_peg = anim["to_peg"]
            self.pegs[to_peg].insert(0, disk)
            self.animation = None
            return False

        return True

    # -----------------------------------------------------------
    # INTERACCIÓN
    # -----------------------------------------------------------
    def peg_at_position(self, pos):
        x, y = pos
        for i, (px, py) in enumerate(self.peg_positions):
            # Área de detección expandida para hacer clic y soltar
            if abs(x - px) < 120 and (py - 250) < y < (py + 20):
                return i
        return None

    def start_drag(self, pos):
        if self.finished or self.animation or self.tutorial_mode: # Ignorar en modo tutorial
            return

        peg = self.peg_at_position(pos)
        if peg is None or not self.pegs[peg]:
            return

        self.dragging_disk = self.pegs[peg].pop(0)
        self.drag_from_peg = peg

    def end_drag(self, pos):
        if self.dragging_disk is None:
            return

        target = self.peg_at_position(pos)

        if target is None or target == self.drag_from_peg:
            self.cancel_drag()
            return

        if self.can_place(self.dragging_disk, target):
            if self.game and self.game.snd_move:
                try: self.game.snd_move.play()
                except: pass

            d = self.dragging_disk
            f = self.drag_from_peg
            
            # Obtener la posición donde se soltó el mouse para un inicio de arco natural
            mx, my = pygame.mouse.get_pos()
            
            # Inicializar la animación con la posición de soltura
            self.animation = {"start_pos": (mx, my)} 
            
            # Llamar a start_drop_animation para calcular la posición final y rellenar el resto de datos.
            self.start_drop_animation(d, f, target)

            self.moves += 1

        else:
            if self.game and self.game.snd_error:
                try: self.game.snd_error.play()
                except: pass

            self.shake_timer = 0.25
            self.shake_intensity = 10
            self.invalid_target = target
            self.cancel_drag()

        self.dragging_disk = None
        self.drag_from_peg = None

    def cancel_drag(self):
        if self.dragging_disk is not None:
            self.pegs[self.drag_from_peg].insert(0, self.dragging_disk)
        self.dragging_disk = None
        self.drag_from_peg = None

    def can_place(self, disk, to_peg):
        if not self.pegs[to_peg]:
            return True
        return disk < self.pegs[to_peg][0]

    # -----------------------------------------------------------
    def get_shake_offset(self, peg_index):
        if peg_index == self.invalid_target and self.shake_timer > 0:
            # Usamos el módulo para hacer que la intensidad oscile entre -1 y 1
            offset = self.shake_intensity * ((self.shake_timer % 0.1) / 0.1) * self.shake_direction
            return int(offset)
        return 0

    # -----------------------------------------------------------
    # SCORE
    # -----------------------------------------------------------
    def calculate_score(self):
        if self.time_enabled:
            time_bonus = max(0, int(self.time_left))
        else:
            time_bonus = 0

        efficiency = max(1, self.min_moves / max(1, self.moves))
        self.score = int(1000 * efficiency + time_bonus)

    # ============================================================
    # 	MODO TUTORIAL — AUTO RESOLUCIÓN
    # ============================================================
    def start_tutorial(self):
        if self.tutorial_mode or self.finished:
            return

        self.tutorial_mode = True
        self.tutorial_moves = []
        self.tutorial_timer = 0
        
        self.generate_solution(self.num_disks, 0, 2, 1)

    def generate_solution(self, n, start, end, aux):
        if n == 1:
            self.tutorial_moves.append((start, end))
            return

        self.generate_solution(n-1, start, aux, end)
        self.tutorial_moves.append((start, end))
        self.generate_solution(n-1, aux, end, start)

    # ============================================================
    # UPDATE
    # ============================================================
    def update(self, dt):
        # 1) Animación
        if self.animation:
            self.update_animation(dt)
            return

        # 2) Tutorial
        if self.tutorial_mode and not self.finished:
            self.tutorial_timer += dt

            if self.tutorial_timer >= 0.45:
                self.tutorial_timer = 0

                if self.tutorial_moves:
                    # El movimiento de tutorial también debe usar la animación de arco
                    frm, to = self.tutorial_moves.pop(0)
                    disk = self.pegs[frm].pop(0)
                    
                    if self.game and self.game.snd_move:
                          try: self.game.snd_move.play()
                          except: pass
                          
                    # Inicia la animación de arco (start_drop_animation se encarga de todo)
                    self.start_drop_animation(disk, frm, to)
                else:
                    self.finished = True
                    self.won = True
                    self.calculate_score()

            return

        # 3) Tiempo
        if self.time_enabled and not self.finished:
            self.time_left -= dt
            if self.time_left <= 0:
                self.time_left = 0
                self.finished = True
                self.won = False

                if self.game and self.game.snd_lose:
                    try: self.game.snd_lose.play()
                    except: pass

        # 4) Victoria normal
        if not self.animation and self.dragging_disk is None:
            # La condición de victoria es que el poste 2 tenga todos los discos
            if len(self.pegs[2]) == self.num_disks and self.pegs[2] == list(range(1, self.num_disks + 1)) and not self.finished:
                self.finished = True
                self.won = True
                self.calculate_score()

                if self.game and self.game.snd_win:
                    try: self.game.snd_win.play()
                    except: pass

        # 5) Shake efecto
        if self.shake_timer > 0:
            self.shake_timer -= dt
        if self.shake_timer <= 0:
            self.shake_intensity = 0
            self.invalid_target = None

        self.shake_direction *= -1

    # ============================================================
    # DRAW BARRA DE TIEMPO
    # ============================================================
    def draw_time_bar(self, surface):
        if not self.time_enabled:
            return

        BAR_WIDTH = 200
        BAR_HEIGHT = 15
        BAR_X = WIDTH - BAR_WIDTH - 30
        BAR_Y = 45 # Posición de la barra de tiempo.

        # Calcular porcentaje
        if self.time_limit > 0:
            percent = self.time_left / self.time_limit
        else:
            percent = 0
            
        current_width = int(BAR_WIDTH * percent)

        # Color de la barra (Verde > Amarillo > Rojo)
        if percent > 0.6:
            color = (50, 200, 50) 	# Verde
        elif percent > 0.25:
            color = (255, 180, 0) 	# Amarillo
        else:
            color = (255, 50, 50) 	# Rojo

        # 1. Fondo de la barra
        pygame.draw.rect(surface, (50, 50, 50), (BAR_X, BAR_Y, BAR_WIDTH, BAR_HEIGHT), border_radius=5)
        
        # 2. Relleno de la barra
        pygame.draw.rect(surface, color, (BAR_X, BAR_Y, current_width, BAR_HEIGHT), border_radius=5)

        # 3. Borde (Glow)
        pygame.draw.rect(surface, (255, 255, 255, 100), (BAR_X, BAR_Y, BAR_WIDTH, BAR_HEIGHT), 1, border_radius=5)
        
        # Efecto de pulso si el tiempo es bajo
        if percent < 0.25 and self.time_left > 0:
             # Genera un valor entre 0 y 1 para el pulso basado en el tiempo
            pulse = abs(self.time_left % 1 - 0.5) * 2 
            alpha = int(pulse * 100) # De 0 a 100
            
            glow_color = (255, 50, 50, alpha)
            glow = pygame.Surface((BAR_WIDTH + 6, BAR_HEIGHT + 6), pygame.SRCALPHA)
            pygame.draw.rect(glow, glow_color, (3, 3, BAR_WIDTH, BAR_HEIGHT), border_radius=7)
            surface.blit(glow, (BAR_X - 3, BAR_Y - 3))


    # ============================================================
    # DRAW
    # ============================================================
    def draw(self, surface, font_small, font_big):
        surface.fill(BACKGROUND_COLOR)

        # HUD (Panel Superior Transparente)
        hud = pygame.Surface((WIDTH, 70), pygame.SRCALPHA)
        hud.fill((0, 0, 0, 90))
        surface.blit(hud, (0, 0))

        # Título del Nivel a la izquierda
        title = font_big.render(f"Nivel {self.level}", True, (0, 255, 180))
        surface.blit(title, (30, 18))

        # Información de movimientos y tiempo (Texto)
        # Posición para "Movs:" (a la derecha, más arriba)
        moves_text = font_small.render(f"Movs: {self.moves}/{self.min_moves}", True, (200, 255, 255))
        surface.blit(moves_text, (WIDTH - 260, 10)) # Ajustado para estar más arriba y a la derecha

        if self.time_enabled:
            # Texto de tiempo encima de la barra (a la derecha, justo encima de BAR_Y)
            time_text = font_small.render(f"Tiempo: {int(self.time_left)}s", True, (200, 255, 255))
            # Calculamos la posición X para centrar el texto encima de la barra o alinearlo.
            # WIDTH - 260 es una buena aproximación para alinear con el texto de "Movs"
            # BAR_Y - 22 para que esté justo encima de la barra (considerando su altura)
            surface.blit(time_text, (WIDTH - 260, self.BAR_Y - 22 if hasattr(self, 'BAR_Y') else 23)) # Usamos self.BAR_Y si ya se ha calculado
        else:
            no_time_text = font_small.render("Modo: Sin Tiempo", True, (200, 255, 255))
            surface.blit(no_time_text, (WIDTH - 260, 23)) # Ajustado para estar debajo de Movs si no hay tiempo

        # Llamar a la barra de tiempo
        self.draw_time_bar(surface) 

        # Parámetros de gráficos de los discos
        disk_h = 22
        max_w = 180
        min_w = 60

        # Postes
        for i, (px, py) in enumerate(self.peg_positions):
            px_adj = px + self.get_shake_offset(i)
            # Dibujar la base
            pygame.draw.line(surface, PEG_COLOR, (px_adj - 100, py), (px_adj + 100, py), 10)
            # Dibujar el poste vertical
            pygame.draw.rect(surface,
                             PEG_COLOR,
                             (px_adj - 7, py - 200, 14, 200),
                             border_radius=5)

        # Discos en postes
        for peg_i, peg in enumerate(self.pegs):
            px, py = self.peg_positions[peg_i]
            px += self.get_shake_offset(peg_i)

            # Iterar sobre los discos, de abajo hacia arriba (reversed)
            for level_idx, disk_size in enumerate(reversed(peg)):
                
                # Cálculo de ancho y color
                t = (disk_size - 1) / max(1, self.num_disks - 1)
                width = int(min_w + (max_w - min_w) * t)
                color = DISK_COLORS[(disk_size - 1) % len(DISK_COLORS)]

                x = px - width // 2
                # Posición Y: base menos la altura acumulada
                y = py - disk_h * (level_idx + 1)

                # Dibujar sombra
                pygame.draw.rect(surface, (0, 0, 0, 60), (x+3, y+3, width, disk_h), border_radius=8)
                # Dibujar disco principal
                pygame.draw.rect(surface, color, (x, y, width, disk_h), border_radius=8)
                # Dibujar borde/brillo
                pygame.draw.rect(surface, (255, 255, 255, 40), (x, y, width, disk_h), 2, border_radius=8)

        # Disco arrastrado (sigue al mouse)
        if self.dragging_disk:
            mx, my = pygame.mouse.get_pos()
            disk = self.dragging_disk

            t = (disk - 1) / max(1, self.num_disks - 1)
            width = int(min_w + (max_w - min_w) * t)
            color = DISK_COLORS[(disk - 1) % len(DISK_COLORS)]

            # Sombra y glow (igual que antes)
            shadow = pygame.Surface((width, disk_h), pygame.SRCALPHA)
            pygame.draw.rect(shadow, (0, 0, 0, 130), (0, 0, width, disk_h), border_radius=8)
            surface.blit(shadow, (mx - width//2 + 5, my - disk_h//2 + 10))

            glow = pygame.Surface((width+12, disk_h+12), pygame.SRCALPHA)
            pygame.draw.rect(glow, (0, 200, 255, 100), (0, 0, width+12, disk_h+12), border_radius=14)
            surface.blit(glow, (mx - width//2 - 6, my - disk_h//2 - 6))

            # Dibujar disco principal
            pygame.draw.rect(surface, color,
                             (mx - width//2, my - disk_h//2,
                              width, disk_h),
                             border_radius=8)

        # Animación en progreso (Movimiento Parabólico)
        if self.animation:
            anim = self.animation
            prog = anim["progress"]
            
            # Aplicar Easing para el movimiento general (suavidad en inicio y fin)
            prog_eased = 1 - (1 - prog) ** 3 	

            x0, y0 = anim["start_pos"]
            x1, y1 = anim["end_pos"]
            
            # 1. Posición Horizontal (Lineal con easing)
            x = x0 + (x1 - x0) * prog_eased
            
            # 2. Posición Vertical (Parabólico)
            # Interpolación lineal de Y (el descenso o ascenso básico)
            y_linear = y0 + (y1 - y0) * prog_eased
            
            # Componente Parabólica (el arco)
            # 4 * prog * (1 - prog) es una parábola que va de 0 a 1 y a 0.
            # Se resta porque el eje Y en Pygame va hacia abajo.
            y_arc = ARC_HEIGHT * 4 * prog * (1 - prog) 

            # La posición final es el movimiento lineal (descenso) MENOS la altura del arco
            y = y_linear - y_arc

            disk = anim["disk"]
            t = (disk - 1) / max(1, self.num_disks - 1)
            width = int(min_w + (max_w - min_w) * t)
            color = DISK_COLORS[(disk - 1) % len(DISK_COLORS)]

            # Dibujar disco animado
            pygame.draw.rect(surface, color,
                             (x - width//2, y - disk_h//2,
                              width, disk_h),
                             border_radius=8)